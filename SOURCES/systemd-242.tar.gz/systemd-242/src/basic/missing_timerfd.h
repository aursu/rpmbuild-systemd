/* SPDX-License-Identifier: LGPL-2.1+ */
#pragma once

#include <sys/timerfd.h>

#ifndef TFD_TIMER_CANCEL_ON_SET
#define TFD_TIMER_CANCEL_ON_SET (1 << 1)
#endif
